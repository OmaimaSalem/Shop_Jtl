<?php
error_reporting(ADMIN_LOG_LEVEL);
date_default_timezone_set(SHOP_TIMEZONE);

define('ADMINGROUP', 1);
define('MAX_LOGIN_ATTEMPTS', 3);
define('LOCK_TIME', 5);
define('SHIPPING_CLASS_MAX_VALIDATION_COUNT', 10);
