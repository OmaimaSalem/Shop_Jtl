<?php // removed in 5.0.0
