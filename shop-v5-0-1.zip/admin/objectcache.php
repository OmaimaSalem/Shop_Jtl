<?php // removed in 4.0
